import os
import pyautogui
import pyttsx3
import speech_recognition 
import requests
from bs4 import BeautifulSoup
import datetime
import pyjokes


engine = pyttsx3.init("sapi5")
voices=engine.getProperty("voices")
engine.setProperty("voice",voices[1].id)
engine.setProperty("rate",160)
def speak(audio):
    engine.say(audio)
    engine.runAndWait()

def takecommand():
    r = speech_recognition.Recognizer()
    with speech_recognition.Microphone() as source:
        print("listening......")
        r.pause_threshold = 1
        r.energy_threshold = 300
        audio = r.listen(source,0,4)
    try:
        print("understanding.....")
        query = r.recognize_google(audio,language='en-in')
        print(f"you said: { query}\n")
    except Exception as e:
        print("say that again")
        return "none"
    return query
def alarm(query):
    timehere = open("Alarmtext.txt","a")
    timehere.write(query)
    timehere.close()
    os.startfile("alarm.py")
def jokes():
    speak(pyjokes.get_joke())



if __name__ == "__main__":
    while True:
        
        query = takecommand().lower()
        if "wake up luna" in query:
            from GreetMe import greetme
            greetme()
        elif "hello luna" in query:
            speak("hi , how are you")
        elif "i am fine " in query:
            speak("That is great")
        elif "how are you " in query:
            speak("i am perfect")
        elif "thank you luna" in query:
            speak("you are welcome")
        elif "open" in query:
            from dictapp import openappweb
            openappweb(query)
        elif "close" in query:
            from dictapp import closeappweb
            closeappweb(query)
        elif "whatsapp" in query:
            from whatsapp import sendMessage
            sendMessage()
        elif "screenshot" in query:
            import pyautogui 
            im = pyautogui.screenshot()
            im.save("ss.jpg")
        elif "click my photo" in query:
            pyautogui.press("super")
            pyautogui.typewrite("camera")
            pyautogui.press("enter")
            pyautogui.sleep(2)
            speak("SMILE")
            pyautogui.press("enter")

            
        elif "google" in query:
            from searchNow import searchGoogle
            searchGoogle(query)
        elif "youtube" in query:
            from searchNow import searchYoutube
            searchYoutube(query)
        elif "wikipedia" in query:
            from searchNow import searchWikipedia
            searchWikipedia(query)
        elif "tell a joke" in query:
            jokes()

        elif "weather" in query:
            search = "weather in islamabad"
            url = f"https://www.google.com/search?q={search}" 
            r = requests.get(url)
            data = BeautifulSoup(r.text,"html.parser")
            weather= data.find("div",class_="BNeawe").text
            speak(f"current{search} is {weather}")
        elif "set an alarm" in query:
            print("input time example:- 10 and 10 and 10")
            speak("Set the time")
            a = input("Please tell the time :- ")
            alarm(a)
            speak("Done,")
        elif "pause" in query:
            pyautogui.press("k")
            speak("video paused")
        elif "play" in query:
            pyautogui.press("k")
            speak("video played")
        elif "mute" in query:
            pyautogui.press("m")
            speak("video muted")

        elif "volume up" in query:
            from keyboard import volumeup
            speak("Turning volume up,")
            volumeup()
        elif "volume down" in query:
            from keyboard import volumedown
            speak("Turning volume down, ")
            volumedown()             

        elif "the time" in query:
            strTime = datetime.datetime.now().strftime("%H:%M")
            speak(f"the time is {strTime}")
        
        elif "sleep luna" in query:
             speak("bye bye, see you again  ")
             exit()



            
    

            
             
             


            

            
